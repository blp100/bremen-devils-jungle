import { IPlayer, IGame } from "@/interfaces";
import { EVOLUTION_TRAITS, PLAYER_TYPE } from "@/constants";

const applyParasiticEffect = (
  attacker: IPlayer,
  damageDealt: number,
  allPlayers: { [key: string]: IPlayer },
) => {
  for (const playerId in allPlayers) {
    const player = allPlayers[playerId];
    if (
      player.evolutionCards?.includes(EVOLUTION_TRAITS.PARASITIC) &&
      player.id !== attacker.id &&
      player.parasiticTargetId === attacker.id
    ) {
      player.hp += damageDealt;
    }
  }
};

export const processCombatPhase = (
  attacker: IPlayer,
  target: IPlayer,
  allPlayers: { [key: string]: IPlayer },
  game: IGame,
) => {
  // Prevent attacking your own minion if you are LION_KING
  if (
    attacker.evolutionCards?.includes(EVOLUTION_TRAITS.LION_KING) &&
    attacker.minionId === target.id
  ) {
    return {
      success: false,
      reason: "You cannot attack your own minion.",
      attacker,
      target,
      damageDealt: 0,
      players: allPlayers,
    };
  }

  // Main combat resolution
  const result = resolveDirectCombat(
    attacker,
    target,
    game.maxElementCount,
    game.damage,
  );

  // Reactive traits
  if (result.success) {
    for (const playerId in allPlayers) {
      const player = allPlayers[playerId];

      // LION_KING: trigger minion follow-up attack
      // TODO: it might be have some logic problem with attack, if the minion attack successed, the damage is 7, the minion would get 4 hp, the lion king would add 3 hp, and the parastic owner would get 4 hp which he's target is minion
      if (
        attacker.evolutionCards?.includes(EVOLUTION_TRAITS.LION_KING) &&
        attacker.minionId === player.id &&
        player.id !== target.id
      ) {
        const minionResult = resolveDirectCombat(
          player,
          target,
          game.maxElementCount,
          game.damage,
        );
        result.damageDealt += minionResult.damageDealt;
        if (minionResult.success) {
          attacker.hp += 3;
          player.hp = Math.max(0, player.hp - 3);
        }
        result.target = minionResult.target; // Update target state after minion attack
        applyParasiticEffect(player, minionResult.damageDealt - 3, allPlayers);
      }
    }
    applyParasiticEffect(attacker, result.damageDealt, allPlayers);
  }

  return {
    ...result,
    players: allPlayers,
  };
};

const resolveDirectCombat = (
  attacker: IPlayer,
  target: IPlayer,
  maxElementCount: number,
  damage: number,
) => {
  const updatedAttacker = { ...attacker };
  const updatedTarget = { ...target };

  applyPreOutcomeEffects(updatedAttacker, updatedTarget);

  const elementValid = _canAttackBasedOnElement(
    attacker,
    target,
    maxElementCount,
  );
  const evolutionValid = _canAttackBasedOnEvolutionCards(attacker, target);

  const success = (elementValid || evolutionValid) && !updatedTarget.protected;

  if (success) {
    updatedAttacker.hp += damage;
    updatedAttacker.isResting = true;

    updatedTarget.hp = Math.max(0, updatedTarget.hp - damage);
    updatedTarget.protected = true;

    applyAfterCombatEffects(updatedAttacker, updatedTarget, success);
  } else {
    updatedAttacker.hp = Math.max(0, updatedAttacker.hp - damage);
    updatedAttacker.isResting = true;
    updatedAttacker.protected = true;

    updatedTarget.hp += damage;

    applyAfterCombatEffects(updatedAttacker, updatedTarget, success);
  }

  return {
    success,
    attacker: updatedAttacker,
    target: updatedTarget,
    damageDealt: damage,
    reason: success ? "Attack succeeded" : "Attack failed",
  };
};

// element combat rules
const FAILED_ATTACK_MAP = {
  [PLAYER_TYPE.FIRE]: PLAYER_TYPE.WATER,
  [PLAYER_TYPE.WATER]: PLAYER_TYPE.WOOD,
  [PLAYER_TYPE.WOOD]: PLAYER_TYPE.FIRE,
  [PLAYER_TYPE.ELECTRIC]: null, // electric can attack everyone
};

const _canAttackBasedOnElement = (
  attacker: IPlayer,
  target: IPlayer,
  maxElementCount: number,
) => {
  if (FAILED_ATTACK_MAP[attacker.type] === target.type) return false;

  if (attacker.type === target.type) {
    return _canAttackBasedOnElementCount(
      attacker.elementCount,
      target.elementCount,
      maxElementCount,
    );
  }

  return true;
};

const _canAttackBasedOnElementCount = (
  attackerElementCount: number,
  targetElementCount: number,
  maxElementCount: number,
) => {
  if ((attackerElementCount % maxElementCount) + 1 === targetElementCount) {
    return false;
  }
  return true;
};

const _canAttackBasedOnEvolutionCards = (
  attacker: IPlayer,
  target: IPlayer,
) => {
  if (
    attacker.evolutionCards?.includes(EVOLUTION_TRAITS.AMPHIBIOUS) &&
    attacker.type === target.type
  )
    return true;
  return false;
};

/**
 * Apply evolution trait effects that occur before the combat result is determined.
 * Example: SHARP_SPIKES — attacker takes damage before attacking.
 */
const applyPreOutcomeEffects = (
  updatedAttacker: IPlayer,
  updatedTarget: IPlayer,
) => {
  if (updatedTarget.evolutionCards?.includes(EVOLUTION_TRAITS.SHARP_SPIKES)) {
    updatedAttacker.hp = Math.max(0, updatedAttacker.hp - 2);
  }

  // Future traits can go here...
};

const applyAfterCombatEffects = (
  updatedAttacker: IPlayer,
  updatedTarget: IPlayer,
  success: boolean,
) => {
  // BLOODTHIRSTY: attacker gains HP, target takes more damage
  if (
    updatedAttacker.evolutionCards?.includes(EVOLUTION_TRAITS.BLOODTHIRSTY) ||
    updatedTarget.evolutionCards?.includes(EVOLUTION_TRAITS.BLOODTHIRSTY)
  ) {
    if (success) {
      updatedAttacker.hp += 2;
      updatedTarget.hp = Math.max(0, updatedTarget.hp - 2);
    } else {
      updatedTarget.hp += 2;
      updatedAttacker.hp = Math.max(0, updatedTarget.hp - 2);
    }
  }

  // DEADLY_POISON: if target dies, attacker also dies
  if (
    updatedTarget.evolutionCards?.includes(EVOLUTION_TRAITS.DEADLY_POISON) &&
    updatedTarget.hp === 0
  ) {
    updatedAttacker.hp = 0;
  }

  // HIBERNATION: attacker becomes protected after successful attack
  if (updatedAttacker.evolutionCards?.includes(EVOLUTION_TRAITS.HIBERNATION)) {
    updatedAttacker.protected = true;
  }

  // Future traits can go here...
};
